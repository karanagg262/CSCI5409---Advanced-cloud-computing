Reference: https://openverse.org/image/b086a242-1285-46f8-bd25-9f437e90ff14?q=apartment
https://openverse.org/image/1ffaa78a-b2c8-4171-895f-4462bd9c0dd4?q=apartment
https://openverse.org/image/682176fd-656c-4e70-8b2a-0b30f4a02ceb?q=apartment