import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-headers',
  templateUrl: './app-headers.component.html',
  styleUrls: ['./app-headers.component.css']
})
export class AppHeadersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
