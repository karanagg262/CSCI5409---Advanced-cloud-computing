import { Component, OnInit } from '@angular/core';
import { Router, Route } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

import { CommonlinkService } from 'src/app/services/commonlink.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  formGroup: FormGroup;
  constructor(private readonly formBuilder: FormBuilder,
    private readonly router: Router,
    private readonly http: HttpClient, 
    private readonly link: CommonlinkService
    ) { }

  ngOnInit() {
    this.createForm();
    this.link.makeURL();
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      'email': [null, Validators.required],
      'password': [null, Validators.required],
    });
  }

  onSubmit() {
    let formData = {
      "email": this.formGroup.value.email,
      "password": this.formGroup.value.password
    }
    const url = this.link.getURL() + 'tenantfetch';
    this.http
			.post( url, formData)
			.subscribe((response: any) => {
				console.log(response);
        if(response.statusCode === 200){
				this.router.navigate(['servicebooking', {
          "data": JSON.stringify(response.body)
        }]);
      }

			});
  }
  onforgetpassword(){
    this.router.navigate(['signup']);
  }
}
