import { Component, OnInit } from '@angular/core';
import { Router, Route, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

import { CommonlinkService } from 'src/app/services/commonlink.service';

@Component({
  selector: 'app-bookservice',
  templateUrl: './bookservice.component.html',
  styleUrls: ['./bookservice.component.css']
})
export class BookserviceComponent implements OnInit {

  formGroup: FormGroup;
  sub:any;
  jsonReceived:any
  name: String;
  unitnumber: String;
  email: String;

  maintenance_type = '';
  comments = '';
  status = '';
  constructor(private readonly formBuilder: FormBuilder,
    private readonly router: Router,
    private readonly http: HttpClient, 
    private readonly activatedroute: ActivatedRoute,
    private readonly link: CommonlinkService
    ) { 
      this.activatedroute.params.subscribe(v => {
        this.jsonReceived = JSON.parse(v['data']);
        this.name = JSON.parse(this.jsonReceived).Item.name.S;
        this.unitnumber = JSON.parse(this.jsonReceived).Item.unitnumber.S;
        this.email = JSON.parse(this.jsonReceived).Item.tenantid.S;
      });
    }

  ngOnInit() {
    this.createForm();
    this.seeServiceRequested();
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      'type': [null, Validators.required],
      'comments': [null, Validators.required],
    });
  }

  onSubmit() {
    let formData = {
      "unitnumber": this.unitnumber,
      "email": this.email,
      "comments": this.formGroup.value.comments,
      "maintenance_type": this.formGroup.value.type,
      "Progress": "UNDER_REVIEW"
    }
    const url = this.link.getURL() + 'servicedetails';
    this.http
    .post( url, formData)
    .subscribe((response: any) => {
      this.maintenance_type = this.formGroup.value.type
      this.comments = this.formGroup.value.comments
      this.status = "UNDER REVIEW"
      
      console.log('response');
    });
  }

  seeServiceRequested(){
    let formData = {
      "unitnumber": this.unitnumber
    }
    const url = this.link.getURL() + 'servicefetch';
    this.http
			.post( url, formData)
			.subscribe((response: any) => {
        if(response.statusCode === 200){
          const data = JSON.parse(response.body)
          this.maintenance_type = data.Item.maintenance_type.S;
          this.comments = data.Item.comments.S;
          this.status = data.Item.progress.S;
      }

			});
  }
}
