import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

import { Signup } from 'src/app/services/signup';
import { CommonlinkService } from 'src/app/services/commonlink.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  formGroup: FormGroup;

  constructor(private readonly formBuilder: FormBuilder, 
    private readonly router: Router,
    private readonly http: HttpClient,
    private readonly link: CommonlinkService) { 
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      'email': [null, Validators.required],
      'name': [null, Validators.required],
      'unitnumber': [null, Validators.required],
      'password': [null, Validators.required],
      'confirmpassword': [null, Validators.required],
    });
  }

  onSubmit() {
    console.log(this.formGroup.value);
    if(this.formGroup.value.password === this.formGroup.value.confirmpassword){
      let formData:Signup = {
        "email": this.formGroup.value.email,
        "name": this.formGroup.value.name,
        "unitnumber": this.formGroup.value.unitnumber, 
        "password": this.formGroup.value.password, 
      }
      const url = this.link.getURL() + 'tenantdetails';
      this.http
          .post(url, formData)
          .subscribe((response: any) => {
              this.router.navigate(['']);
      });
    }
  }
}
