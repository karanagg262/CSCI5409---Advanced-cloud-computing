export interface Signup {
    "email": string;
    "name": string;
    "unitnumber": string;
    "password": string;
}
