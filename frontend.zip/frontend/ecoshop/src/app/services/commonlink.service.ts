import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { concat } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonlinkService {

url = '';
constructor(
  private readonly http: HttpClient
) { }

makeURL(){
  this.http.get("../assets/environment", { responseType: 'text'}).subscribe(data => {
    this.url  = "https://"+data+".execute-api.us-east-1.amazonaws.com/testing/"
});
}

getURL(){
  return this.url;
}

}
