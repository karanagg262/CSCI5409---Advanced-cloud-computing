/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { CommonlinkService } from './commonlink.service';

describe('Service: Commonlink', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommonlinkService]
    });
  });

  it('should ...', inject([CommonlinkService], (service: CommonlinkService) => {
    expect(service).toBeTruthy();
  }));
});
